package com.student;

import java.util.ArrayList;
import java.util.Scanner;

public class MarksCalculatorWithCollections {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> marksList = new ArrayList<>();

        System.out.print("Enter the number of subjects: ");
        int numSubjects = sc.nextInt();

        // Input marks using ArrayList
        for (int i = 0; i < numSubjects; i++) {
            System.out.print("Enter marks for subject " + (i + 1) + " (out of 100): ");
            int mark = sc.nextInt();

            // Validate input
            while (mark < 0 || mark > 100) {
                System.out.print("Invalid input. Please enter marks between 0 and 100: ");
                mark = sc.nextInt();
            }

            marksList.add(mark);
        }

        // Calculate total
        int totalMarks = 0;
        for (int mark : marksList) {
            totalMarks += mark;
        }

        // Calculate average
        double averagePercentage = (double) totalMarks / numSubjects;

        // Grade logic
        String grade;
        if (averagePercentage >= 90) {
            grade = "A+";
        } else if (averagePercentage >= 80) {
            grade = "A";
        } else if (averagePercentage >= 70) {
            grade = "B";
        } else if (averagePercentage >= 60) {
            grade = "C";
        } else if (averagePercentage >= 50) {
            grade = "D";
        } else {
            grade = "F (Fail)";
        }

        // Display Results
        System.out.println("\n--- Result ---");
        System.out.println("Total Marks: " + totalMarks + " out of " + (numSubjects * 100));
        System.out.printf("Average Percentage: %.2f%%\n", averagePercentage);
        System.out.println("Grade: " + grade);

        sc.close();
    }
}
